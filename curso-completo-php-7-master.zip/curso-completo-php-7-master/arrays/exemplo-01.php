<?php

$frutas = array("laranja", "abacaxi", "melancia");

print_r($frutas);

?>