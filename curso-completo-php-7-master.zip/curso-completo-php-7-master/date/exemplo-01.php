<?php

echo date("d/m/Y H:i:s", 1484936340);

echo "<br/>";

echo time();

?>